export default function AboutPage() {
    return `
    <div class="about-page">
        <h1>About Page</h1>
        <p>This is the about page... Website ini adalah aplikasi web untuk menentukan game apa yang akan kamu mainkan berdasarkan rekomendasi dari pengguna lainnya.</p>
        <p>Jika ada hal yang ingin kamu sampaikan, kami akan senang hati mendengarnya.</p>
    </div>
    `;
}